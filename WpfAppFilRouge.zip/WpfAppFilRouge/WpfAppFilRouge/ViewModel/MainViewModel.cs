﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppFilRouge.ViewModel
{
    internal class MainViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private bibliothequeEntities _context = new bibliothequeEntities();

        readonly Lazy<ObservableCollection<Livre>> _livres;

        public IEnumerable<Livre> Livre
        {
            get { return _livres.Value; }
        }

        public MainViewModel()
        {
            _livres = new Lazy<ObservableCollection<Livre>>(() => GetLivres());
        }

        private ObservableCollection<Livre> GetLivres()
        {
            _context.Livre.Load();
            return _context.Livre.Local;
        }
    }
}
